package com.card.infoshelf.bottomfragment;

public class networkModel {

    String profession, userId;

    public networkModel() {
    }

    public networkModel(String profession, String userId) {
        this.profession = profession;
        this.userId = userId;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
