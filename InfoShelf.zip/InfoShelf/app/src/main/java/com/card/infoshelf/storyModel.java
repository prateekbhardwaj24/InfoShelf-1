package com.card.infoshelf;

public class storyModel {

    private String imageUrl;
    private long timeStart;
    private long timeEnd;
    private String stortid;
    private String userid;

    public storyModel(String imageUrl, long timeStart, long timeEnd, String stortid, String userid) {
        this.imageUrl = imageUrl;
        this.timeStart = timeStart;
        this.timeEnd = timeEnd;
        this.stortid = stortid;
        this.userid = userid;
    }

    public storyModel() {
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public long getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(long timeStart) {
        this.timeStart = timeStart;
    }

    public long getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(long timeEnd) {
        this.timeEnd = timeEnd;
    }

    public String getStortid() {
        return stortid;
    }

    public void setStortid(String stortid) {
        this.stortid = stortid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
