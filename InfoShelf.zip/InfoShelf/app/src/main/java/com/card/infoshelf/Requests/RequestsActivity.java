package com.card.infoshelf.Requests;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.card.infoshelf.R;
import com.card.infoshelf.myProfileTabaccessAdaptor;
import com.google.android.material.tabs.TabLayout;

public class RequestsActivity extends AppCompatActivity {
    private ViewPager myViewPager;
    private TabLayout myTabLayout;
    private RequestsTabAccessAdapter requestsTabAccessAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);

        myViewPager = findViewById(R.id.my_profile_pager);
        requestsTabAccessAdapter = new RequestsTabAccessAdapter(this.getSupportFragmentManager());
        myViewPager.setAdapter(requestsTabAccessAdapter);

        myTabLayout = findViewById(R.id.my_profile_tabs);
        myTabLayout.setupWithViewPager(myViewPager);
    }
}