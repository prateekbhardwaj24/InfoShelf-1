package com.card.infoshelf.bottomfragment;

import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.card.infoshelf.R;
import com.card.infoshelf.storyAdaptor;
import com.card.infoshelf.storyModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TimelineFragment extends Fragment {

    private RecyclerView storiesRecycler;
    private storyAdaptor adaptor;
    private List<storyModel> mstory;
    private BottomSheetDialog bottomSheetDialog;
    private ImageView filter;
    CheckBox allcheck;
    Spinner company_tag_spin,interest_tag_spin;
    String getInterest,getCompany;
    Integer getCheck;
    TextView donebtn;
    DataBaseHelper myDb;
    DataBaseHelper myDb2;
    DataBaseHelper myDb3;

    TextView checkval,comval,intval;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_timeline, container, false);

        storiesRecycler = root.findViewById(R.id.storiesRecycler);
        filter = root.findViewById(R.id.filter);
        checkval = root.findViewById(R.id.checkboxval);
        comval = root.findViewById(R.id.companyval);
        intval = root.findViewById(R.id.interval);
//        allcheck = bottomSheetDialog.findViewById(R.id.all_check);
        storiesRecycler.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        storiesRecycler.setLayoutManager(linearLayoutManager);
        mstory = new ArrayList<>();
        adaptor = new storyAdaptor(getActivity(), mstory);
        storiesRecycler.setAdapter(adaptor);

       // bottom sheet
        bottomSheetDialog = new BottomSheetDialog(getActivity(), R.style.BottomSheetStyle);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.timeline_filter_bottom_sheet, (LinearLayout)root.findViewById(R.id.sheet2));
        bottomSheetDialog.setContentView(view);
        allcheck = bottomSheetDialog.findViewById(R.id.all_check);
        company_tag_spin = bottomSheetDialog.findViewById(R.id.comapny_tag_spinner);
         interest_tag_spin = bottomSheetDialog.findViewById(R.id.interest_tag_spinner);

//        updateData();
      //interest spinner
                String[] ArrayInterest = {"None","Effective communication", "Teamwork", "Responsibility", "Creativity", "Problem-solving", "Leadership", "Extroversion", "People skills", "Openness", "Adaptability", "Data analysis", "Web analytics", "Wordpress", "Email marketing", "Web scraping", "CRO and A/B Testing", "Data visualization & pattern-finding through critical thinking", "Search Engine and Keyword Optimization", "Project/campaign management", "Social media and mobile marketing", "Paid social media advertisements", "B2B Marketing", "The 4 P-s of Marketing", "Consumer Behavior Drivers", "Brand management", "Creativity", "Copywriting", "Storytelling", "Sales", "CMS Tools", "Six Sigma techniques", "The McKinsey 7s Framework", "Porter’s Five Forces", "PESTEL", "Emotional Intelligence", "Dealing with work-related stress", "Motivation", "Task delegation", "Technological savviness", "People management", "Business Development", "Strategic Management", "Negotiation", "Planning", "Proposal writing", "Problem-solving", "Innovation", "Charisma", "Algorithms", "Analytical Skills", "Big Data", "Calculating", "Compiling Statistics", "Data Analytics", "Data Mining", "Database Design", "Database Management", "Documentation", "Modeling", "Modification", "Needs Analysis", "Quantitative Research", "Quantitative Reports", "Statistical Analysis", "HTML", "Implementation", "Information Technology", "ICT (Information and Communications Technology)", "Infrastructure", "Languages", "Maintenance", "Network Architecture", "Network Security", "Networking", "New Technologies", "Operating Systems", "Programming", "Restoration", "Security", "Servers", "Software", "Solution Delivery", "Storage", "Structures", "Systems Analysis", "Technical Support", "Technology", "Testing", "Tools", "Training", "Troubleshooting", "Usability", "Benchmarking", "Budget Planning", "Engineering", "Fabrication", "Following Specifications", "Operations", "Performance Review", "Project Planning", "Quality Assurance", "Quality Control", "Scheduling", "Task Delegation", "Task Management", "Content Management Systems (CMS)", "Blogging", "Digital Photography", "Digital Media", "Networking", "Search Engine Optimization (SEO)", "Social Media Platforms (Twitter, Facebook, Instagram, LinkedIn, TikTok, Medium, etc.)", "Web Analytics", "Automated Marketing Software", "Client Relations", "Email", "Requirements Gathering", "Research", "Subject Matter Experts (SMEs)", "Technical Documentation", "Information Security", "Microsoft Office Certifications", "Video Creation", "Customer Relationship Management (CRM)", "Productivity Software", "Cloud/SaaS Services", "Database Management", "Telecommunications", "Human Resources Software", "Accounting Software", "Enterprise Resource Planning (ERP) Software", "Database Software", "Query Software", "Blueprint Design", "Medical Billing", "Medical Coding", "Sonography", "Structural Analysis", "Artificial Intelligence (AI)", "Mechanical Maintenance", "Manufacturing", "Inventory Management", "Numeracy", "Information Management", "Hardware Verification Tools and Techniques", "PHP", "TypeScript", "Scala", "Shell", "PowerShell", "Perl", "Haskell", "Kotlin", "Visual Basic .NET", "SQL", "Delphi", "MATLAB", "Groovy", "Lua", "Rust", "Ruby", "HTML and CSS", "Python", "Java", "JavaScript", "Swift", "C++", "C#", "R", "Golang (Go)", "Soccer", "Football", "Cycling", "Running", "Basketball", "Swimming", "Tennis", "Baseball", "Yoga", "Hiking", "Camping", "Fishing", "Trekking", "Mountain climbing", "Gardening", "Drawing", "Painting", "Watercoloring", "Sculpture", "Woodworking", "Dance", "graphics designing", "Front-End development", "Back-End development", "Content Writting", "essay writting", "Event organising", "Hackathon", "Bookkeeping", "Graphic design", "Data analysis", "Microsoft Excel", "Public speaking", "Budgeting", "Teaching", "Research", "Microsoft Word", "Scheduling", "Sales", "Project management", "Office management", "Fundraising", "Writing", "Editing", "Event promotion", "Event planning", "Bilingual", "Management experience", "Communication skills (both written and oral)", "Customer service", "Problem-solving", "Organizational skills", "Inventive", "Handling conflict", "Listening", "Attention to detail", "Collaboration", "Curious", "Diplomacy", "Friendly", "Flexible", "Responsible", "Punctual", "Reliable", "Takes initiative", "Persistent", "Leadership", "Enthusiastic", "Android Studio", "Android Development", "Web Development", "Machine Learning", "Artificial intelligence", "Robots", "Augmented reality", "virtual reality", "Cryptography", "Hacking", "Xml"};
                //create an adapter to describe how the items are displayed, adapters are used in several places in android.
                //There are multiple variations of this, but this is the basic variant.
                ArrayAdapter<String> interestAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_dropdown_item, ArrayInterest);
                //set the spinners adapter to the previously created one.
                interest_tag_spin.setAdapter(interestAdapter);

        //company spinner
                String[] ArrayCompany = {"None","Reliance Industries", "Indian Oil Corporation", "Oil  Natural Gas Corporation", "State Bank of India", "Bharat Petroleum Corporation", "Tata Motors", "Rajesh Exports", "Tata Consultancy Services", "ICICI Bank", "Larsen  Toubro", "HDFC Bank", "Tata Steel", "Hindalco Industries", "NTPC", "HDFC", "Coal India", "Mahindra  Mahindra", "Infosys", "Bank of Baroda", "Bharti Airtel", "Nayara Energy", "Vedanta", "Axis Bank", "Grasim Industries", "Maruti Suzuki India", "GAIL (India)", "JSW Steel", "HCL Technologies", "Steel Authority of India", "Punjab National Bank", "Motherson Sumi Systems", "Wipro", "Power Finance Corporation", "Canara Bank", "Bajaj Finserv", "ITC", "General Insurance Corporation of India", "Kotak Mahindra Bank", "Bank of India", "Vodafone Idea", "Jindal Steel  Power", "Union Bank of India", "UltraTech Cement", "Power Grid Corporation of India", "Hindustan Unilever", "Tech Mahindra", "Yes Bank", "InterGlobe Aviation", "UPL", "IndusInd Bank", "Sun Pharmaceuticals Industries", "NABARD", "Bajaj Auto", "Tata Power Company", "Hero MotoCorp", "New India Assurance Company", "IFFCO", "Adani Power", "Ambuja Cements", "Central Bank of India", "IDBI Bank", "Avenue Supermarts", "Indian Bank", "Aurobindo Pharma", "Reliance Capital", "Bharat Heavy Electricals", "Reliance Infrastructure", "Titan Company", "Hindustan Aeronautics", "Ashok Leyland", "Asian Paints", "Indian Overseas Bank", "Future Retail", "Sundaram Clayton", "LIC Housing Finance", "TVS Motor Company", "Max Financial Services", "Dr. Reddys Laboratories", "PTC India", "UCO Bank", "IDFC First Bank", "Cipla", "Citibank", "Tata Chemicals", "Tata Communications", "Aditya Birla Capital", "EID Parry (India)", "Shriram Transport Finance Company", "MRF", "Apollo Tyres", "Toyota Kirloskar Motor", "Lupin", "ACC", "Federal Bank", "Piramal Enterprises", "Rail Vikas Nigam", "Exide Industries", "Oil India", "Standard Chartered Bank", "Cadila Healthcare", "Siemens", "Torrent Power", "HSBC", "Adani Ports and Special Economic Zone", "Indiabulls Housing Finance", "SpiceJet", "SIDBI", "National Fertilizer", "Jindal Stainless", "Bank of Maharashtra", "Shree Cement", "Bharat Electronics", "Kalpataru Power Transmission", "Nestle India", "Macrotech Developers", "NMDC", "Bandhan Bank", "Gujarat State Petronet", "Chambal Fertilisers  Chemicals", "Bombay Burmah Trading Corporation", "Godrej Industries", "KEC International", "MM Financial Services", "CESC", "Britannia Industries", "NLC India", "Adani Transmission", "godrej  Boyce Manufacturing Company", "Apollo Hospitals Enterprise", "Jindal Saw", "Adani Enterprises", "Varroc Engineering", "Welspun Corp", "Jaiprakash Associates", "NHPC", "Rain Industries", "Glenmark Pharmaceuticals", "RBL Bank", "Bosch", "Godrej Consumer Products", "Afcons Infrastructure", "Hindustan Construction Company", "Dalmia Bharat", "Rashtriya Chemicals  Fertilizers", "Tata Capital", "Tata Consumer Products", "Dilip Buildcon", "Muthoot Finance", "Eicher Motors", "Edelweiss Financial Services", "Dewan Housing Finance Corporation", "Jubilant Life Sciences", "Havells India", "United Spirits", "GMR Infrastructure", "JSW Energy", "Aditya Birla Fashion  Retail", "Polycab India", "National Aluminium Company", "Dabur India", "Mphasis", "Aster DM Healthcare", "NCC", "jammu and Kashmir Bank", "Punjab  Sind Bank", "South Indian Bank", "JK Tyre  Industries", "Cholamandalam Investment  Finance Co.", "Varun Beverages", "Alkem Laboratories", "Export-Import Bank of India", "Bharti Infratel", "Security  Intelligence Services (India)", "DCM Shriram", "NBCC (India)", "Reliance Power", "Torrent Pharmaceuticals", "Bharat Forge", "Voltas", "marico", "APL Apollo Tubes", "Karnataka Bank", "Mahindra CIE Automotive", "BASF India", "Shree Renuka Sugars", "GSFC", "Whirlpool of India", "Apar Industries", "HUDCO", "Uflex", "Allcargo Logistics", "SRF", "ABB India", "Pidilite Industries", "Deutsche Bank", "Arvind", "DLF", "Aegis Logistics", "Karur Vysya Bank", "IRB Infrastructure Developers", "Birla Corporation", "Raymond", "Vardhman Textiles", "Welspun India", "Endurance Technologies", "Thomas Cook (India)", "Container Corporation Of India", "Amara Raja Batteries", "CEAT", "Biocon", "Prestige Estates Projects", "Bajaj Hindusthan Sugar", "United Breweries", "Berger Paints India", "Future Lifestyle Fashions", "Jain Irrigation Systems", "Shriram City Union Finance", "Prism Johnson", "SREI Infrastructure Finance", "ISGEC Heavy Engineering", "JK Cement", "Escorts", "Sterling  Wilson Solar", "Thermax", "Fullerton India Credit Company", "PNC Infratech", "Supreme Industries", "PC Jeweller", "Divis Laboratories", "Hexaware Technologies", "Surya Roshni", "Mazagon Dock Shipbuilders", "Ircon International", "Manappuram Finance", "Cummins India", "Minda Industries", "Nirma", "The Ramco Cements", "Future Enterprises", "Blue Star", "Zee Entertainment Enterprises", "Sadbhav Engineering", "GNFC", "National Housing Bank", "Kansai Nerolac Paints", "The India Cements", "Hatsun Agro Product", "Team Lease Services", "Ashoka Buildcon", "CG Power  Industrial Solutions", "Sterlite Technologies", "Hinduja Global Solutions", "Oracle Financial Services Software", "KEI Industries", "AGC Networks", "Balkrishna Industries", "AU Small Finance Bank", "Bajaj Electricals", "Walmart India", "Fortis Healthcare", "Ipca Laboratories", "City Union Bank", "Alembic Pharmaceuticals", "IIFL Finance", "Trident", "India Infrastructure Finance Company", "Balrampur Chini Mills", "Sundaram Finance", "Bank of America", "Crompton Greaves Consumer Electrical", "Shipping Corporation of India", "Tube Investments of India", "Indian Hotels Co", "RattanIndia Power", "Deepak Fertilisers  Petrochemicals Corp", "Polyplex Corporation", "Cyient", "Colgate-Palmolive (India)", "JK Lakshmi Cement", "Dixon Technologies (India)", "Schaeffler India", "KRBL", "Triveni Engineering and Industries", "Zensar Technologies", "Coforge", "Deepak Nitrite", "Avanti Feeds", "Aarti Industries", "Atul", "Sobha", "Zuari Agro Chemicals", "Abbott India", "Firstsource Solutions", "Simplex Infrastructures", "LT Foods", "Future Consumer", "Jubilant Foodworks", "Amber Enterprises India", "Tamilnad Mercantile Bank", "Tamil Nadu Newsprint  Papers", "HFCL", "Great Eastern Shipping Company", "DCB Bank", "GSK Pharmaceuticals", "Castrol India", "Gujarat Ambuja Exports", "Sonata Software", "Sun TV Network", "The Fertilizers  Chemicals Travancore", "Gokul Agro Resources", "Trent", "Persistent Systems", "Sundram Fasteners", "Cochin Shipyard", "Shoppers Stop", "Jindal Poly Films", "Jayaswal Neco Industries", "Gayatri Projects", "Bayer CropScience", "Time Technoplast", "Dish TV India", "JK Paper", "KPR Mill", "Jaiprakash Power Ventures", "Kirloskar Oil Engines", "Century Textiles  Industries", "Engineers India", "India Glycols", "Dhampur Sugar Mills", "Oberoi Realty", "JM Financial", "PVR", "PI Industries", "Honeywell Automation India", "BEML", "Birlasoft", "SJVN", "GHCL", "IFB Industries", "Phillips Carbon Black", "Electrotherm (India)", "Godawari Power  Ispat", "GE TD India", "Venkys (India)", "Blue Dart Express", "Graphite India", "Kirloskar Brothers", "Sanofi India", "Bata India", "Narayana Hrudayalaya", "Finolex Industries", "Brigade Enterprises", "Godfrey Phillips India", "AIA Engineering", "Laurus Labs", "Finolex Cables", "PG Hygiene and Health Care", "Heritage Foods", "Force Motors", "Mukand", "Prime Focus", "J Kumar Infraprojects", "Jai Balaji Industries", "Prakash Industries", "Ujjivan Financial Services", "SKF India", "Strides Pharma Science", "Page Industries", "Montecarlo", "Equitas Holdings", "Indiabulls Real Estate", "Dhani Services", "Kajaria Ceramics", "Forbes  Company", "IFCI", "Wockhardt", "ITD Cementation India", "Nava Bharat Ventures", "Garden Silk Mills", "Redington India", "Electrosteel Castings", "Godrej Properties", "JBF Industries", "Filatex India", "RSWM", "Patel Engineering", "EPL", "Gujarat Alkalies  Chemicals", "G4S Secure Solutions (India)", "Minda Corporation", "Gland Pharma", "Transport Corporation of India", "Konkan Railway Corporation", "BGR Energy Systems", "Akzo Nobel India", "Supreme Petrochem", "Granules India", "Emami", "Bharat Dynamics", "Brightcom Group", "Asahi India Glass", "Ratnamani Metals  Tubes", "Maharashtra Seamless", "Ajanta Pharma", "Shankara Building Products", "Carborundum Universal", "Kesoram Industries", "GFL", "Astral Poly Technik", "Orient Cement", "Rites", "West Coast Paper Mills", "Wheels India", "V-Guard Industries", "Usha Martin", "Parag Milk Foods", "Linde India", "Avadh Sugar  Energy", "Va Tech Wabag", "HIL", "Huhtamaki PPL", "GE Power India", "Canon India", "Galaxy Surfactants", "Magma Fincorp", "Lakshmi Vilas Bank", "Suzlon Energy", "KNR Constructions", "Denso Haryana", "Jayant Agro Organics", "Relaxo Footwears", "MEP Infrastructure Developers", "Radico Khaitan", "Sutlej Textiles and Industries", "BNP Paribas", "Siyaram Silk Mills", "Jana Small Finance Bank", "Himatsingka Seide", "Johnson Controls - Hitachi Air Condition. India", "Religare Enterprises", "3M India", "Dalmia Bharat Sugar  Industries", "Nectar Lifescience", "Pfizer", "Transcorp International", "Motilal Oswal Financial Services", "IRCTC", "Hindusthan National Glass  Industries", "HT Media", "Solar Industries India", "NIIT", "Sumitomo Chemical India", "Century Plyboards (India)", "Sify Technologies", "Nilkamal", "Vindhya Telelinks", "Meghmani Organics", "Cosmo Films", "Take Solutions", "DB Corp", "H.G. Infra Engineering", "HEG", "Rane Holdings", "HeidelbergCement India", "Sheela Foam", "Indo Rama Synthetics (India)", "Jindal Worldwide", "Orient Electric", "Power Mech Projects", "KPIT Technologies", "American Express Bank", "Pennar Industries", "Jagran Prakashan", "VRL Logistics", "TVS Srichakra", "Dishman Carbogen Amcis", "Indo Count Industries", "Natco Pharma", "TTK Prestige", "Southern Petrochemical Industries Corporation", "Subros", "KIOCL", "Savita Oil Technologies", "Nahar Spinning Mills", "Sharda Cropchem", "Gokul Refoils and Solvent", "Sarda Energy  Minerals", "HSIL", "Max Healthcare Institute", "Greaves Cotton", "WABCO India", "Tanla Platforms", "Bombay Dyeing  Manufacturing Company", "Sandhar Technologies", "Texmaco Rail  Engineering", "Phoenix Mills", "Kirloskar Industries", "Bilcare", "Ahluwalia Contracts (India)", "IOL Chemicals  Pharmaceuticals", "Flipkart", "Vmware", "Nutanix", "Oyo rooms", "Goibibo", "MakeMyTrip", "Wow! Momo", "Ola Cabs", "AddressHealth", "Zomato", "One97 (Paytm)", "FreshToHome", "‍FreshMenu", "Flyrobe", "Myra", "Cure.Fit", "Dunzo", "Shuttl", "Digit Insurance", "CoolBerg", "Cleardekho", "The Minimalist", "Razorpay", "Nineleaps", "Innov8 Coworking", "Schbang", "Acko General Insurance", "Treebo Hotels", "InCred", "Jumbotail", "DocTalk", "Smallcase", "Vedantu", "Instavans", "Loan Frame", "Overcart", "Flock", "Doctor Insta", "Cowrks", "1Mg", "Cars24", "Dailyhunt", "Ebutor", "Meesho", "MilkBasket", "PharmEasy", "Policybazaar", "Revv", "Sharechat", "Nykaa", "Toppr", "TravelTriangle", "Urban Ladder", "Aisle", "Me", "Bombay Shaving Company", "POPxo", "Zestmoney", "Xpressbees", "Swiggy", "Boeing", "Snapdeal", "Jio", "Arcesium", "Amazon", "Microsoft", "Apple", "Netflix", "Facebook", "Snapdeal", "Ixigo", "Walmart", "Hashedin", "Linkedin", "Zomato", "Swiggy", "Uber", "Urban company", "Dunzo", "Kronos", "Tekio", "Mmt", "Adobe", "Cadence", "Genpact", "Jp morgan", "Salesforce", "Visa", "Phonepe", "Mpl", "Deloitte", "Qualcomm", "Mind tree", "Zoho", "Atlassian", "Skack", "Ibm", "Oracle", "Dell", "Samsung", "Sap", "Goibibo", "Paytm", "Paypal", "Gojek", "Mckinsey", "Vedantu", "Sharechat", "Reliance jio", "Vmware", "Harness", "Kafka", "Morgan Stanley", "Nutanix", "Pratilipi", "Digital guardian", "Flobiz", "Grab", "Coforge ltd", "SanDisk", "Target", "Jaro tech", "Scaler", "McAfee", "Boeing", "Siemens", "Texas instruments", "Commvault", "Veeam", "Radware", "Amdocs", "Innovaccer", "Intuit", "Inmobi", "Curefit", "Infosys specialist programmer", "Arcesium", "Optum", "Publicis sapient", "Exl", "Sony", "Hughes systique technology (hst)", "Tata cliq", "Wells Fargo", "Sandive", "Global logic", "Bny melon", "Ion group"};
                //create an adapter to describe how the items are displayed, adapters are used in several places in android.
                //There are multiple variations of this, but this is the basic variant.
                ArrayAdapter<String> company_adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_dropdown_item, ArrayCompany);
                //set the spinners adapter to the previously created one.
                company_tag_spin.setAdapter(company_adapter);



                //-------------------validate search fields---------------
        validateSearch();

        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.show();
            }
        });

//sqlite data -----------------
        myDb =new DataBaseHelper(getContext());
        donebtn = bottomSheetDialog.findViewById(R.id.DoneFilter);
        donebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                sendDataToSQL();

                bottomSheetDialog.cancel();
            }
        });


        return root;
    }

    private void updateData() {
        myDb =new DataBaseHelper(getContext());
        Boolean result = myDb.updateData("1",getCheck,getCompany,getInterest);
        if (result == true){
            Toast.makeText(getContext(), "DAta updated", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(getContext(), "DAta not updated", Toast.LENGTH_SHORT).show();
        }
    }

    private void getData() {
        myDb =new DataBaseHelper(getContext());
        Cursor res  = myDb.getAllData();
        StringBuffer stringBuffer = new StringBuffer();
        if (res!=null &&res.getCount() >0){
            while (res.moveToNext()){
                stringBuffer.append("CHECKBOX : " + res.getString(1)+"\n");
                stringBuffer.append("COMPANYSPIN : " + res.getString(2)+"\n");
                stringBuffer.append("INTERESTSPIN : " + res.getString(3)+"\n"+"\n");
            }
            checkval.setText(stringBuffer.toString());
            Toast.makeText(getContext(), "DAta Retreived", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getContext(), "something error in databse", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendDataToSQL() {
      Boolean result = myDb.insertData(getCheck,getCompany,getInterest);
      if (result == true){
          Toast.makeText(getContext(), "Data saved", Toast.LENGTH_SHORT).show();
      }else{
          Toast.makeText(getContext(), "Data not saved try again", Toast.LENGTH_SHORT).show();
      }
    }

    private void validateSearch() {

        allcheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (allcheck.isChecked()){
                    company_tag_spin.setSelection(0);
                    interest_tag_spin.setSelection(0);
                    getCheck = 1;
                }
            }
        });
        company_tag_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

              getCompany = parent.getItemAtPosition(position).toString();

                if (company_tag_spin.getSelectedItemPosition() != 0){
                    interest_tag_spin.setSelection(0);
                    allcheck.setChecked(false);
                    getCheck = 0;
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        interest_tag_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              getInterest = parent.getItemAtPosition(position).toString();


                if (interest_tag_spin.getSelectedItemPosition() != 0){
                    company_tag_spin.setSelection(0);
                    allcheck.setChecked(false);
                    getCheck = 0;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

//    private  void readStory(){
//        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Story");
//        reference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                long timeCurent = System.currentTimeMillis();
//                mstory.clear();
//                mstory.add(new storyModel("", 0, 0, "", FirebaseAuth.getInstance().getCurrentUser().getUid()));
//                for (String id: )
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }


}