package com.card.infoshelf.bottomfragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.card.infoshelf.R;
import com.card.infoshelf.allUserActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class NetworkFragment extends Fragment {

    private RecyclerView network_recycler, peoples_u_recycler;
    private ArrayList<networkModel> list, userList;
    private DatabaseReference userInfoRef;
    private network_adaptor adaptor, allUserAdaptor;
    private FirebaseAuth mAuth;
    private String CurrentUserId;
    private TextView more_rec, more_umk;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_network, container, false);

        network_recycler = root.findViewById(R.id.network_recycler);
        peoples_u_recycler = root.findViewById(R.id.peoples_u_recycler);
        more_rec = root.findViewById(R.id.more_rec);
        more_umk = root.findViewById(R.id.more_umk);

        mAuth = FirebaseAuth.getInstance();
        userInfoRef = FirebaseDatabase.getInstance().getReference("UserDetails");
        CurrentUserId = mAuth.getCurrentUser().getUid();

        network_recycler.setHasFixedSize(true);
        network_recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        network_recycler.setItemAnimator(new DefaultItemAnimator());

        peoples_u_recycler.setHasFixedSize(true);
        peoples_u_recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        peoples_u_recycler.setItemAnimator(new DefaultItemAnimator());

        list = new ArrayList<>();
        userList = new ArrayList<>();
        adaptor = new network_adaptor(getActivity(),list);
        allUserAdaptor = new network_adaptor(getActivity(), userList);
        network_recycler.setAdapter(adaptor);
        peoples_u_recycler.setAdapter(allUserAdaptor);


        more_rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), allUserActivity.class);
                intent.putExtra("type", "recommended");
                startActivity(intent);
            }
        });

        more_umk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), allUserActivity.class);
                intent.putExtra("type", "umk");
                startActivity(intent);
            }
        });

        userInfoRef.child(CurrentUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String getProf = snapshot.child("profession").getValue().toString();

                userInfoRef.orderByChild("profession").equalTo(getProf).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                            networkModel user = dataSnapshot.getValue(networkModel.class);
                            list.add(user);
                        }
                        adaptor.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        getAllUsers();

        return root;
    }

    private void getAllUsers() {
        userInfoRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    networkModel user = dataSnapshot.getValue(networkModel.class);
                    userList.add(user);
                }
                allUserAdaptor.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}