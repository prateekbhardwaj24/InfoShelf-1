package com.card.infoshelf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.card.infoshelf.bottomfragment.networkModel;
import com.card.infoshelf.bottomfragment.network_adaptor;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class allUserActivity extends AppCompatActivity {

    private RecyclerView allUserRecycler;
    private ArrayList<networkModel> list;
    private allUserAdaptor adaptor;
    private DatabaseReference userInfoRef;
    private String type;
    private FirebaseAuth mAuth;
    private String CurrentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_user);

        type = getIntent().getStringExtra("type").toString();
        allUserRecycler = findViewById(R.id.allUserRecycler);

        mAuth = FirebaseAuth.getInstance();
        CurrentUserId = mAuth.getCurrentUser().getUid();
        userInfoRef = FirebaseDatabase.getInstance().getReference("UserDetails");

        allUserRecycler.setHasFixedSize(true);
        allUserRecycler.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        adaptor = new allUserAdaptor(this,list);
        allUserRecycler.setAdapter(adaptor);

        if (type.equals("recommended")){

            userInfoRef.child(CurrentUserId).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String getProf = snapshot.child("profession").getValue().toString();

                    userInfoRef.orderByChild("profession").equalTo(getProf).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                                networkModel user = dataSnapshot.getValue(networkModel.class);
                                list.add(user);
                            }
                            adaptor.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        else {

            userInfoRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        networkModel user = dataSnapshot.getValue(networkModel.class);
                        list.add(user);
                    }
                    adaptor.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
}